// Create your global variables below:
var tracklist = ["Let It Happen", "Nangs", "The Moment", "Yes I'm Changing", "Eventually", "Gossip", "The Less I Know The Better", "Past Life", "Disciples", "'Cause I'm A Man"];
var volLevels = [];
var currVol = 3;
var song = 6;

function init() {
	// Your code goes here
for (var i=0; i<3; i++) {
  volLevel = document.getElementById("vl" + i);  
  volLevel.style.backgroundColor = "#9f5cc4";}

}

function volUp() {
	// Your code goes here

  buttonup = document.getElementById("vl" + currVol);
   if(currVol<6)
    { 
      buttonup.style.backgroundColor = "#9f5cc4";
      currVol++;
    }

      
}

function volDown() {
	// Your code goes here
  
	
   if(currVol>0)
    { 
      currVol--;
      buttondown = document.getElementById("vl" + currVol);
      buttondown.style.backgroundColor = "";

    }
}

function clock(){

  
  if(document.getElementById("time").value<180)
  {
    
    document.getElementById("time").value++;
    document.getElementById("player-time").innerHTML=
        secondsToMs(document.getElementById("player-time").value);

  }

  if(document.getElementById("time").value==180) {
        nextSong();
    }

   document.getElementById("player-time").innerHTML=
        secondsToMs(document.getElementById("time").value);


  
  }

function switchPlay() {
	// Your code goes here

    x=document.getElementById("switch").innerHTML;
   if(x == "play_arrow")
    { 
      setInterval(clock,1000);
      document.getElementById("switch").innerHTML="pause";
      
     
    }
  else
     {
      document.getElementById("switch").innerHTML="play_arrow";
      for(var i =0;i<2000;i++){
            clearInterval(i);
        }
    }
   

}

function nextSong() {
	// Your code goes here

    if(song<9){
        song++;
        document.getElementById("player-song-name").innerHTML= tracklist[song];
        document.getElementById("time").value=0;
    }
    else{
        song=0;
        document.getElementById("player-song-name").innerHTML= tracklist[song];
        document.getElementById("time").value=0;
    }
}

function prevSong() {
	// Your code goes here
  if(song<=0){
        song=8;
        document.getElementById("player-song-name").innerHTML= tracklist[song];
        document.getElementById("time").value=0;
    }
    else{
        song--;
        document.getElementById("player-song-name").innerHTML= tracklist[song];
        document.getElementById("time").value=0;
    }
}

function secondsToMs(d) {
    d = Number(d);

    var min = Math.floor(d / 60);
    var sec = Math.floor(d % 60);

    return `0${min}`.slice(-1) + ":" + `00${sec}`.slice(-2);
}

init();